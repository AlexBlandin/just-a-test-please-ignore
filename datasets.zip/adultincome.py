import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

def load_adult_income_dataset(only_train = True):
  """Loads adult income dataset from https://archive.ics.uci.edu/ml/datasets/Adult and prepares
       the data for data analysis based on https://rpubs.com/H_Zhu/235617

    :return adult_data: returns preprocessed adult income dataset.
    """
  raw_data = np.genfromtxt("adult.data", delimiter = ", ", dtype = str, invalid_raise = False)
  
  # column names from "https://archive.ics.uci.edu/ml/datasets/Adult"
  column_names = [
    "age", "workclass", "fnlwgt", "education", "educational-num", "marital-status", "occupation", "relationship",
    "race", "gender", "capital-gain", "capital-loss", "hours-per-week", "native-country", "income"
  ]
  
  adult_data = pd.DataFrame(raw_data, columns = column_names)
  
  # for more details on how the below transformations are made, please refer to https://rpubs.com/H_Zhu/235617
  adult_data = adult_data.astype({"age": np.int64, "educational-num": np.int64, "hours-per-week": np.int64})
  
  adult_data = adult_data.replace({"workclass": {"Without-pay": "Other/Unknown", "Never-worked": "Other/Unknown"}})
  adult_data = adult_data.replace({
    "workclass": {
      "Federal-gov": "Government",
      "State-gov": "Government",
      "Local-gov": "Government"
    }
  })
  adult_data = adult_data.replace({"workclass": {"Self-emp-not-inc": "Self-Employed", "Self-emp-inc": "Self-Employed"}})
  adult_data = adult_data.replace({"workclass": {"Never-worked": "Self-Employed", "Without-pay": "Self-Employed"}})
  adult_data = adult_data.replace({"workclass": {"?": "Other/Unknown"}})
  
  adult_data = adult_data.replace({
    "occupation": {
      "Adm-clerical": "White-Collar",
      "Craft-repair": "Blue-Collar",
      "Exec-managerial": "White-Collar",
      "Farming-fishing": "Blue-Collar",
      "Handlers-cleaners": "Blue-Collar",
      "Machine-op-inspct": "Blue-Collar",
      "Other-service": "Service",
      "Priv-house-serv": "Service",
      "Prof-specialty": "Professional",
      "Protective-serv": "Service",
      "Tech-support": "Service",
      "Transport-moving": "Blue-Collar",
      "Unknown": "Other/Unknown",
      "Armed-Forces": "Other/Unknown",
      "?": "Other/Unknown"
    }
  })
  
  adult_data = adult_data.replace({
    "marital-status": {
      "Married-civ-spouse": "Married",
      "Married-AF-spouse": "Married",
      "Married-spouse-absent": "Married",
      "Never-married": "Single"
    }
  })
  
  adult_data = adult_data.replace({
    "race": {
      "Black": "Other",
      "Asian-Pac-Islander": "Other",
      "Amer-Indian-Eskimo": "Other"
    }
  })
  
  adult_data = adult_data[[
    "age", "workclass", "education", "marital-status", "occupation", "race", "gender", "hours-per-week", "income"
  ]]
  
  adult_data = adult_data.replace({"income": {"<=50K": 0, ">50K": 1}})
  
  adult_data = adult_data.replace({
    "education": {
      "Assoc-voc": "Assoc",
      "Assoc-acdm": "Assoc",
      "11th": "School",
      "10th": "School",
      "7th-8th": "School",
      "9th": "School",
      "12th": "School",
      "5th-6th": "School",
      "1st-4th": "School",
      "Preschool": "School"
    }
  })
  
  adult_data = adult_data.rename(columns = {"marital-status": "marital_status", "hours-per-week": "hours_per_week"})
  
  if only_train:
    train, _ = train_test_split(adult_data, test_size = 0.2, random_state = 17)
    adult_data = train.reset_index(drop = True)
  
  return adult_data
