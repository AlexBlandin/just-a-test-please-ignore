from pathlib import Path
import math

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer, LabelEncoder
import pandas as pd

feature_descriptions = {
  "Target":
    "Target variable (1 = client with payment difficulties: they had late payment more than X days on at least one of the first Y installments of the loan in our sample, 0 = all other cases)",
  "Revolving Loan":
    "Identification if loan is cash or revolving (0 = Cash loan, 1 = Revolving loan)",
  "Owns Car":
    "Flag if the client owns a car (0 = No, 1 = Yes)",
  "Owns Realty":
    "Flag if client owns a house or flat (0 = No, 1 = Yes)",
  "Children":
    "Number of children the client has",
  "Income Total":
    "Income of the client",
  "Credit":
    "Credit amount of the loan",
  "Annuity":
    "Loan annuity (regular payments towards the loan)",
  "Goods Price":
    "The price of the goods for which the loan is given for consumer loans",
  "Income Type":
    "Clients income type",
  "Education Type":
    "Level of highest education the client achieved",
  "Family Status":
    "Family status of the client",
  "Housing Type":
    "What is the housing situation of the client",
  "Age":
    "Client's age in years at the time of application",
  "Days Employed":
    "How many days before the application the person started current employment (-999 for unknown or not applicable)",
  "Days ID Unchanged":
    "How many days before the application did client change the identity document with which they applied for the loan",
  "Occupation Type":
    "What kind of occupation does the client have",
  "Organisation Type":
    "Type of organisation where client works",
  "External Score 1":
    "Normalized score from external credit/risk rating (-999 for unknown or not applicable)",
  "External Score 2":
    "Normalized score from external credit/risk rating (-999 for unknown or not applicable)",
  "External Score 3":
    "Normalized score from external credit/risk rating (-999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Hour":
    "Number of enquiries to Credit Bureau about the client one hour before application (-999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Day":
    "Number of enquiries to Credit Bureau about the client one day before application (excluding one hour before application, -999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Week":
    "Number of enquiries to Credit Bureau about the client one week before application (excluding one day before application, -999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Month":
    "Number of enquiries to Credit Bureau about the client one month before application (excluding one week before application, -999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Quarter":
    "Number of enquiries to Credit Bureau about the client 3 month before application (excluding one month before application, -999 for unknown or not applicable)",
  "Enquiries to Credit Bureau in Year":
    "Number of enquiries to Credit Bureau about the client one year before application (excluding last 3 months before application, -999 for unknown or not applicable)"
}
cats = {
  "Income Type": [
    "Businessman", "Commercial associate", "Maternity leave", "Pensioner", "State servant", "Student", "Unemployed",
    "Working"
  ],
  "Education Type": [
    "Academic degree", "Higher education", "Incomplete higher", "Lower secondary", "Secondary / secondary special"
  ],
  "Family Status": ["Civil marriage", "Married", "Separated", "Single / not married", "Status Unknown", "Widow"],
  "Housing Type": [
    "Co-op apartment", "House / apartment", "Municipal apartment", "Office apartment", "Rented apartment",
    "With parents"
  ],
  "Occupation Type": [
    "Accountants", "Cleaning staff", "Cooking staff", "Core staff", "Drivers", "HR staff", "High skill tech staff",
    "IT staff", "Laborers", "Low-skill Laborers", "Managers", "Medicine staff", "Private service staff",
    "Realty agents", "Sales staff", "Secretaries", "Security staff", "Waiters/barmen staff", "Occupation Unknown"
  ],
  "Organisation Type": [
    "Advertising", "Agriculture", "Bank", "Business", "Cleaning", "Construction", "Culture", "Electricity", "Emergency",
    "Government", "Hotel", "Housing", "Industry", "Insurance", "Kindergarten", "Legal Services", "Medicine", "Military",
    "Mobile", "Other", "Police", "Postal", "Realtor", "Religion", "Restaurant", "School", "Security",
    "Security Ministries", "Self-employed", "Services", "Telecom", "Trade", "Transport", "University", "Not Applicable"
  ]
}
continuous_features = ["Children", "Income Total", "Credit", "Annuity", "Goods Price", "Age", "Days Employed", "Days ID Unchanged", "External Score 1", "External Score 2", "External Score 3", "Enquiries to Credit Bureau in Hour", "Enquiries to Credit Bureau in Day", "Enquiries to Credit Bureau in Week", "Enquiries to Credit Bureau in Month", "Enquiries to Credit Bureau in Quarter", "Enquiries to Credit Bureau in Year"]

replacements = {
  "Revolving Loan": {
    "Cash loans": 0,
    "Revolving loans": 1
  },
  "Owns Car": {
    "N": 0,
    "Y": 1
  },
  "Owns Realty": {
    "N": 0,
    "Y": 1
  },
  "Days Employed": {
    365243: -999
  },
  "Family Status": {
    "Unknown": "Status Unknown"
  },
  "Occupation Type": {
    math.nan: "Occupation Unknown",
    "": "Occupation Unknown"
  },
  "Organisation Type": {
    "XNA": "Not Applicable",
    "Business Entity Type 1": "Business",
    "Business Entity Type 2": "Business",
    "Business Entity Type 3": "Business",
    "Industry: type 1": "Industry",
    "Industry: type 10": "Industry",
    "Industry: type 11": "Industry",
    "Industry: type 12": "Industry",
    "Industry: type 13": "Industry",
    "Industry: type 2": "Industry",
    "Industry: type 3": "Industry",
    "Industry: type 4": "Industry",
    "Industry: type 5": "Industry",
    "Industry: type 6": "Industry",
    "Industry: type 7": "Industry",
    "Industry: type 8": "Industry",
    "Industry: type 9": "Industry",
    "Trade: type 1": "Trade",
    "Trade: type 2": "Trade",
    "Trade: type 3": "Trade",
    "Trade: type 4": "Trade",
    "Trade: type 5": "Trade",
    "Trade: type 6": "Trade",
    "Trade: type 7": "Trade",
    "Transport: type 1": "Transport",
    "Transport: type 2": "Transport",
    "Transport: type 3": "Transport",
    "Transport: type 4": "Transport"
  }
}

def clean_data(path = Path("!application_data.csv"), to = Path("data.csv")):
  data = pd.read_csv(path)
  
  for col in list(data.columns):
    if col not in feature_descriptions: data = data.drop(col, axis = 1)
  
  for category, reps in replacements.items():
    for d, rep in reps.items():
      data[category] = data[category].replace([d], rep)
  
  data["Age"] = data["Age"].apply(lambda x: abs(x) / 365.2425)
  data["Days Employed"] = data["Days Employed"].abs()
  data["Days ID Unchanged"] = data["Days ID Unchanged"].abs()
  
  data = data.replace([math.nan, math.inf], -999) # common way to special case unknowns/errors out of numerical data
  
  # filter down so we have as many of each case, only 8% of the app data is "risky", we need a balanced data
  risky = data[data["Target"] == 1]
  unrisky = data[data["Target"] == 0].sample(sum(data["Target"]))
  data = pd.concat([risky, unrisky],
                   ignore_index = True).reset_index(drop = True).sample(frac = 1).reset_index(drop = True)
  
  data = onehot(data)
  data.to_csv(to, index = False)
  return data

def onehot(data, cats = cats):
  # One hot encoding
  for cat, labels in cats.items():
    enc = LabelBinarizer()
    transformed = enc.fit_transform(data[cat])
    names = list(enc.classes_)
    try:
      assert set(names) <= set(cats[cat])
    except Exception as err:
      print(sorted(set(names)))
      print(sorted(set(cats[cat])))
      print(sorted(set(cats[cat]) ^ set(names)))
      raise err
    onehot = pd.DataFrame(transformed, columns = names)
    missing = pd.DataFrame(columns = [c for c in cats[cat] if c not in names])
    onehot = pd.concat([onehot, missing], axis = 1).replace([math.nan], 0)
    data = pd.concat([data.drop([cat], axis = 1), onehot], axis = 1)
  
  data.columns = data.columns.astype(str)
  return data

def load_csv(path, split = True, ohe = True):
  data = pd.read_csv(path)
  return (data.drop("Target", axis = 1), data["Target"]) if split else data

def loan_data(path = Path("data.csv"), split = True, ohe = True):
  return load_csv(path, split = split, ohe = ohe)

def scenarios(path = Path("scenarios.csv"), split = True, ohe = True):
  return load_csv(path, split = split, ohe = ohe)

def row_as_dict(df, row_i):
  return df[row_i:row_i+1].to_dict("index")[0]

if __name__ == "__main__":
  clean_data()
  X_train, y_train = loan_data()
  print(X_train.head())
  X_train, y_train = scenarios()
  print(X_train.head())
